import React, { Suspense, lazy } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Hero from "./components/Hero";
import FeaturedCategories from "./components/FeaturedCategories";
import SignatureCollection from "./components/SignatureCollection";
import About from "./components/About";
import Gallery from "./components/Gallery";
import Testimonials from "./components/Testimonials";
import Contact from "./components/Contact";
import Footer from "./components/Footer";

// Lazy load the collection page since it's not on the main route
const CollectionPage = lazy(() => import("./components/CollectionPage"));

// Loading component
const LoadingSpinner = () => (
  <div className="flex items-center justify-center min-h-screen">
    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-amber-600"></div>
  </div>
);

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-stone-50">
        <Header />
        <Routes>
          <Route
            path="/"
            element={
              <>
                <Hero />
                <FeaturedCategories />
                <SignatureCollection />
                <About />
                <Gallery />
                <Testimonials />
                <Contact />
              </>
            }
          />
          <Route
            path="/collection/:category"
            element={
              <Suspense fallback={<LoadingSpinner />}>
                <CollectionPage />
              </Suspense>
            }
          />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
