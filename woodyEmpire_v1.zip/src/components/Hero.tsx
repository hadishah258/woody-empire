import React from "react";
import { ChevronDown } from "lucide-react";

const Hero = () => {
  return (
    <section
      id="home"
      className="relative h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg"
          alt="Premium wooden furniture"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 text-center text-white px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          {/* Urdu Accent */}
          <div className="mb-4">
            <span
              className="text-amber-300 text-lg font-light opacity-80"
              style={{ fontFamily: "serif" }}
            >
              ہنر اور خوبصورتی
            </span>
          </div>

          <h1
            className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6 leading-tight"
            style={{ fontFamily: "Playfair Display" }}
          >
            Crafted Elegance <br />
            <span className="text-amber-300">from Pakistan</span>
          </h1>

          <p
            className="text-xl sm:text-2xl mb-8 font-light max-w-2xl mx-auto leading-relaxed"
            style={{ fontFamily: "Lato" }}
          >
            Where traditional craftsmanship meets contemporary design, creating
            timeless pieces for discerning homes
          </p>

          <div className="flex flex-col items-center space-y-4">
            <button className="bg-amber-700 hover:bg-amber-800 text-white px-8 py-4 text-lg font-medium transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl border border-amber-600">
              <a href="#collections">Explore Collections</a>
            </button>

            {/* Scroll Indicator - positioned below the button */}
            <div className="animate-bounce">
              <ChevronDown size={32} className="text-white/70" />
            </div>
          </div>
        </div>
      </div>

      {/* Decorative Border */}
      <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-amber-600 via-amber-500 to-amber-600"></div>
    </section>
  );
};

export default Hero;
