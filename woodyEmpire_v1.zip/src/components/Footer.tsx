import React from "react";
import {
  Facebook,
  Instagram,
  Twitter,
  Mail,
  Phone,
  MapPin,
} from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-stone-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="lg:col-span-1">
            <h3
              className="text-2xl font-bold mb-4 text-amber-300"
              style={{ fontFamily: "Playfair Display" }}
            >
              Woody Empire
            </h3>
            <p
              className="text-stone-300 mb-6 leading-relaxed"
              style={{ fontFamily: "Lato" }}
            >
              Crafting exceptional furniture that celebrates Pakistani heritage
              while embracing modern design sensibilities. Where tradition meets
              innovation.
            </p>
            <div className="flex space-x-4">
              <a
                href="#"
                className="text-stone-300 hover:text-amber-300 transition-colors"
              >
                <Facebook size={24} />
              </a>
              <a
                href="#"
                className="text-stone-300 hover:text-amber-300 transition-colors"
              >
                <Instagram size={24} />
              </a>
              <a
                href="#"
                className="text-stone-300 hover:text-amber-300 transition-colors"
              >
                <Twitter size={24} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4
              className="text-lg font-bold mb-4 text-amber-300"
              style={{ fontFamily: "Playfair Display" }}
            >
              Quick Links
            </h4>
            <ul className="space-y-2" style={{ fontFamily: "Lato" }}>
              <li>
                <a
                  href="#home"
                  className="text-stone-300 hover:text-amber-300 transition-colors"
                >
                  Home
                </a>
              </li>
              <li>
                <a
                  href="#collections"
                  className="text-stone-300 hover:text-amber-300 transition-colors"
                >
                  Collections
                </a>
              </li>
              <li>
                <a
                  href="#about"
                  className="text-stone-300 hover:text-amber-300 transition-colors"
                >
                  About Us
                </a>
              </li>
              <li>
                <a
                  href="#gallery"
                  className="text-stone-300 hover:text-amber-300 transition-colors"
                >
                  Gallery
                </a>
              </li>
              <li>
                <a
                  href="#contact"
                  className="text-stone-300 hover:text-amber-300 transition-colors"
                >
                  Contact
                </a>
              </li>
            </ul>
          </div>

          {/* Collections */}
          <div>
            <h4
              className="text-lg font-bold mb-4 text-amber-300"
              style={{ fontFamily: "Playfair Display" }}
            >
              Collections
            </h4>
            <ul className="space-y-2" style={{ fontFamily: "Lato" }}>
              <li>
                <a
                  href="#collections"
                  className="text-stone-300 hover:text-amber-300 transition-colors"
                >
                  Living Room
                </a>
              </li>
              <li>
                <a
                  href="#collections"
                  className="text-stone-300 hover:text-amber-300 transition-colors"
                >
                  Bedroom
                </a>
              </li>
              <li>
                <a
                  href="#collections"
                  className="text-stone-300 hover:text-amber-300 transition-colors"
                >
                  Dining
                </a>
              </li>
              <li>
                <a
                  href="#collections"
                  className="text-stone-300 hover:text-amber-300 transition-colors"
                >
                  Office
                </a>
              </li>
              <li>
                <a
                  href="#collections"
                  className="text-stone-300 hover:text-amber-300 transition-colors"
                >
                  Custom
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4
              className="text-lg font-bold mb-4 text-amber-300"
              style={{ fontFamily: "Playfair Display" }}
            >
              Contact Info
            </h4>
            <div className="space-y-3" style={{ fontFamily: "Lato" }}>
              <div className="flex items-start">
                <MapPin
                  className="text-amber-300 mr-3 mt-1 flex-shrink-0"
                  size={16}
                />
                <div className="text-stone-300 text-sm">
                  Main Murree Road
                  <br />
                  Waris Khan Stop
                  <br />
                  Rawalpindi, Pakistan
                </div>
              </div>
              <div className="flex items-center">
                <Phone
                  className="text-amber-300 mr-3 flex-shrink-0"
                  size={16}
                />
                <span className="text-stone-300 text-sm">+92 3049997996</span>
              </div>
              <div className="flex items-center">
                <Mail className="text-amber-300 mr-3 flex-shrink-0" size={16} />
                <span className="text-stone-300 text-sm">
                  woodyempire.furniture@gmail.com
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Decorative Border */}
        <div className="border-t border-stone-700 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div
              className="text-stone-400 text-sm mb-4 md:mb-0"
              style={{ fontFamily: "Lato" }}
            >
              © 2024 Woody Empire. All rights reserved. | Handcrafted with ❤️ in
              Pakistan
            </div>
            <div
              className="text-stone-400 text-sm"
              style={{ fontFamily: "serif" }}
            >
              ہنر اور محنت سے بنایا گیا
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
