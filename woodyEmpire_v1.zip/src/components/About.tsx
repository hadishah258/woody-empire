import React from 'react';
import { Award, Heart, Users, Hammer } from 'lucide-react';

const About = () => {
  const values = [
    {
      icon: Hammer,
      title: 'Traditional Craftsmanship',
      description: 'Time-honored techniques passed down through generations of skilled artisans'
    },
    {
      icon: Heart,
      title: 'Passionate Design',
      description: 'Every piece reflects our love for Pakistani culture and modern aesthetics'
    },
    {
      icon: Award,
      title: 'Premium Quality',
      description: 'Only the finest materials and meticulous attention to detail'
    },
    {
      icon: Users,
      title: 'Family Heritage',
      description: 'A legacy of woodworking excellence spanning three generations'
    }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <div>
            <div className="mb-8">
              <h2 className="text-4xl font-bold text-stone-800 mb-4" style={{ fontFamily: 'Playfair Display' }}>
                Rooted in Heritage, <br />
                <span className="text-amber-700">Crafted for Tomorrow</span>
              </h2>
              <div className="w-24 h-1 bg-amber-600 mb-6"></div>
              <div className="space-y-6 text-lg leading-relaxed text-stone-600" style={{ fontFamily: 'Lato' }}>
                <p>
                  At Woody Empire, we celebrate the rich tradition of Pakistani woodworking while embracing contemporary design sensibilities. Our master craftsmen combine time-tested techniques with modern innovation to create furniture that tells a story.
                </p>
                <p>
                  From the bustling workshops of Lahore to the finest homes across Pakistan and beyond, each piece represents our commitment to excellence, sustainability, and the preservation of our cultural heritage.
                </p>
                <p>
                  We source our materials responsibly, work with local artisans, and ensure that every creation meets the highest standards of quality and durability.
                </p>
              </div>
            </div>

            {/* Urdu Quote */}
            <div className="bg-amber-50 border-l-4 border-amber-600 p-6 mb-8">
              <p className="text-amber-800 text-xl mb-2" style={{ fontFamily: 'serif' }}>
                "ہر لکڑی کی اپنی کہانی ہے، ہم اسے خوبصورت شکل دیتے ہیں"
              </p>
              <p className="text-stone-600 italic" style={{ fontFamily: 'Lato' }}>
                "Every piece of wood has its own story, we give it a beautiful form"
              </p>
            </div>
          </div>

          {/* Image */}
          <div className="relative">
            <img
              src="https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg"
              alt="Craftsman at work"
              className="w-full rounded-xl shadow-2xl"
            />
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-amber-600 rounded-xl flex items-center justify-center transform rotate-3 shadow-lg">
              <div className="text-white text-center">
                <div className="text-2xl font-bold" style={{ fontFamily: 'Playfair Display' }}>25+</div>
                <div className="text-sm" style={{ fontFamily: 'Lato' }}>Years</div>
              </div>
            </div>
          </div>
        </div>

        {/* Values Grid */}
        <div className="mt-20 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {values.map((value, index) => {
            const IconComponent = value.icon;
            return (
              <div
                key={index}
                className="text-center group hover:transform hover:-translate-y-2 transition-all duration-300"
              >
                <div className="bg-amber-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-amber-200 transition-colors duration-300">
                  <IconComponent className="text-amber-700" size={32} />
                </div>
                <h3 className="text-xl font-bold text-stone-800 mb-3" style={{ fontFamily: 'Playfair Display' }}>
                  {value.title}
                </h3>
                <p className="text-stone-600 leading-relaxed" style={{ fontFamily: 'Lato' }}>
                  {value.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default About;