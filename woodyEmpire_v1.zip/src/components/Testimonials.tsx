import React from 'react';
import { Quote, Star } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      name: 'Ahmed Hassan',
      location: 'Karachi',
      image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg',
      rating: 5,
      text: 'Woody Empire transformed our living room with their exquisite craftsmanship. The attention to detail and quality of materials is unmatched. Truly proud to have Pakistani artistry in our home.'
    },
    {
      name: 'Sarah Khan',
      location: 'Lahore',
      image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg',
      rating: 5,
      text: 'The bedroom set we ordered exceeded all expectations. The fusion of traditional Pakistani designs with modern functionality is brilliant. Highly recommended for anyone seeking luxury furniture.'
    },
    {
      name: 'Dr. Malik Rahman',
      location: 'Islamabad',
      image: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg',
      rating: 5,
      text: 'As a collector of fine furniture, I can confidently say Woody Empire represents the pinnacle of Pakistani craftsmanship. Their custom pieces are works of art.'
    }
  ];

  const projects = [
    {
      title: 'Luxury Villa - DHA Phase 5',
      location: 'Karachi',
      image: 'https://images.pexels.com/photos/1648776/pexels-photo-1648776.jpeg',
      description: 'Complete home furnishing with custom-designed pieces'
    },
    {
      title: 'Corporate Office - Gulberg',
      location: 'Lahore',
      image: 'https://images.pexels.com/photos/667838/pexels-photo-667838.jpeg',
      description: 'Executive furniture suite for multinational company'
    },
    {
      title: 'Heritage Hotel - F-7',
      location: 'Islamabad',
      image: 'https://images.pexels.com/photos/1395967/pexels-photo-1395967.jpeg',
      description: 'Traditional Pakistani furniture for boutique hotel'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-stone-800 mb-4" style={{ fontFamily: 'Playfair Display' }}>
            Client Stories & Projects
          </h2>
          <div className="w-24 h-1 bg-amber-600 mx-auto mb-6"></div>
          <p className="text-lg text-stone-600 max-w-2xl mx-auto" style={{ fontFamily: 'Lato' }}>
            Discover what our clients say about their experience and explore some of our most prestigious projects
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Testimonials */}
          <div>
            <h3 className="text-2xl font-bold text-stone-800 mb-8" style={{ fontFamily: 'Playfair Display' }}>
              What Our Clients Say
            </h3>
            <div className="space-y-8">
              {testimonials.map((testimonial, index) => (
                <div
                  key={index}
                  className="bg-stone-50 p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300"
                >
                  <div className="flex items-start mb-4">
                    <img
                      src={testimonial.image}
                      alt={testimonial.name}
                      className="w-16 h-16 rounded-full object-cover mr-4"
                    />
                    <div className="flex-1">
                      <div className="flex items-center mb-2">
                        <h4 className="font-bold text-stone-800 mr-2" style={{ fontFamily: 'Playfair Display' }}>
                          {testimonial.name}
                        </h4>
                        <div className="flex">
                          {[...Array(testimonial.rating)].map((_, i) => (
                            <Star key={i} size={16} className="text-amber-500 fill-current" />
                          ))}
                        </div>
                      </div>
                      <p className="text-stone-600 text-sm" style={{ fontFamily: 'Lato' }}>
                        {testimonial.location}
                      </p>
                    </div>
                    <Quote className="text-amber-300 opacity-50" size={24} />
                  </div>
                  <p className="text-stone-700 leading-relaxed" style={{ fontFamily: 'Lato' }}>
                    "{testimonial.text}"
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Project Highlights */}
          <div>
            <h3 className="text-2xl font-bold text-stone-800 mb-8" style={{ fontFamily: 'Playfair Display' }}>
              Featured Projects
            </h3>
            <div className="space-y-6">
              {projects.map((project, index) => (
                <div
                  key={index}
                  className="group cursor-pointer overflow-hidden rounded-xl shadow-lg hover:shadow-2xl transition-all duration-500"
                >
                  <div className="flex">
                    <img
                      src={project.image}
                      alt={project.title}
                      className="w-24 h-24 object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="flex-1 p-4 bg-white">
                      <h4 className="font-bold text-stone-800 mb-1" style={{ fontFamily: 'Playfair Display' }}>
                        {project.title}
                      </h4>
                      <p className="text-amber-600 text-sm font-medium mb-2" style={{ fontFamily: 'Lato' }}>
                        {project.location}
                      </p>
                      <p className="text-stone-600 text-sm" style={{ fontFamily: 'Lato' }}>
                        {project.description}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;