import React from 'react';
import { Link } from 'react-router-dom';
import { Star } from 'lucide-react';

const SignatureCollection = () => {
  const signaturePieces = [
    {
      name: 'Heritage Dining Set',
      image: 'https://images.pexels.com/photos/1395967/pexels-photo-1395967.jpeg',
      description: 'Handcrafted with traditional joinery techniques',
      features: ['Solid Sheesham Wood', 'Hand-carved Details', '8-Seater Configuration']
    },
    {
      name: 'Royal Living Suite',
      image: 'https://images.pexels.com/photos/1648776/pexels-photo-1648776.jpeg',
      description: 'Luxury seating inspired by Mughal architecture',
      features: ['Premium Upholstery', 'Brass Accents', 'Custom Cushions']
    },
    {
      name: 'Artisan Bedroom Collection',
      image: 'https://images.pexels.com/photos/271816/pexels-photo-271816.jpeg',
      description: 'Contemporary comfort with traditional aesthetics',
      features: ['Storage Integration', 'Carved Headboard', 'Matching Wardrobes']
    }
  ];

  return (
    <section className="py-20 bg-stone-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-4">
            <Star className="text-amber-600 mr-2" size={24} />
            <h2 className="text-4xl font-bold text-stone-800" style={{ fontFamily: 'Playfair Display' }}>
              Signature Collection
            </h2>
            <Star className="text-amber-600 ml-2" size={24} />
          </div>
          <div className="w-32 h-1 bg-amber-600 mx-auto mb-6"></div>
          <p className="text-lg text-stone-600 max-w-3xl mx-auto" style={{ fontFamily: 'Lato' }}>
            Our most celebrated pieces, each representing the pinnacle of Pakistani craftsmanship and design excellence
          </p>
        </div>

        {/* Signature Pieces Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {signaturePieces.map((piece, index) => (
            <div
              key={index}
              className="group bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2"
            >
              <div className="relative overflow-hidden">
                <img
                  src={piece.image}
                  alt={piece.name}
                  className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>
              
              <div className="p-8">
                <h3 className="text-2xl font-bold text-stone-800 mb-3" style={{ fontFamily: 'Playfair Display' }}>
                  {piece.name}
                </h3>
                <p className="text-stone-600 mb-6 leading-relaxed" style={{ fontFamily: 'Lato' }}>
                  {piece.description}
                </p>
                
                {/* Features */}
                <div className="space-y-3">
                  {piece.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-center">
                      <div className="w-2 h-2 bg-amber-600 rounded-full mr-3"></div>
                      <span className="text-stone-700 font-medium" style={{ fontFamily: 'Lato' }}>
                        {feature}
                      </span>
                    </div>
                  ))}
                </div>

                {/* View Details Button */}
                <Link 
                  to="/collection/signature"
                  className="mt-6 w-full bg-gradient-to-r from-amber-600 to-amber-700 text-white py-3 px-6 font-medium hover:from-amber-700 hover:to-amber-800 transition-all duration-300 transform hover:scale-105 shadow-md hover:shadow-lg block text-center"
                >
                  View Collection
                </Link>
              </div>

              {/* Decorative Border */}
              <div className="h-1 bg-gradient-to-r from-amber-500 via-amber-600 to-amber-700"></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SignatureCollection;