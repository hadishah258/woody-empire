import React from 'react';
import { Link } from 'react-router-dom';
import { Home, Bed, UtensilsCrossed, Briefcase, Wrench } from 'lucide-react';

const FeaturedCategories = () => {
  const categories = [
    {
      name: 'Living Room',
      icon: Home,
      image: 'https://images.pexels.com/photos/1648776/pexels-photo-1648776.jpeg',
      description: 'Elegant sofas and seating'
    },
    {
      name: 'Bedroom',
      icon: Bed,
      image: 'https://images.pexels.com/photos/271816/pexels-photo-271816.jpeg',
      description: 'Luxurious bedroom sets'
    },
    {
      name: 'Dining',
      icon: UtensilsCrossed,
      image: 'https://images.pexels.com/photos/1395967/pexels-photo-1395967.jpeg',
      description: 'Handcrafted dining tables'
    },
    {
      name: 'Office',
      icon: Briefcase,
      image: 'https://images.pexels.com/photos/667838/pexels-photo-667838.jpeg',
      description: 'Professional workspaces'
    },
    {
      name: 'Custom',
      icon: Wrench,
      image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg',
      description: 'Bespoke furniture designs'
    }
  ];

  return (
    <section id="collections" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-stone-800 mb-4" style={{ fontFamily: 'Playfair Display' }}>
            Featured Collections
          </h2>
          <div className="w-24 h-1 bg-amber-600 mx-auto mb-6"></div>
          <p className="text-lg text-stone-600 max-w-2xl mx-auto" style={{ fontFamily: 'Lato' }}>
            Discover our carefully curated collections, each piece telling a story of Pakistani artisanship and modern elegance
          </p>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
          {categories.map((category, index) => {
            const IconComponent = category.icon;
            return (
              <Link
                to={`/collection/${category.name.toLowerCase().replace(' ', '-')}`}
                key={index}
                className="group cursor-pointer transform transition-all duration-500 hover:scale-105"
              >
                <div className="relative overflow-hidden rounded-lg shadow-lg hover:shadow-2xl transition-shadow duration-300">
                  <img
                    src={category.image}
                    alt={category.name}
                    className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent group-hover:from-amber-800/60 transition-colors duration-300"></div>
                  
                  {/* Content */}
                  <div className="absolute inset-0 flex flex-col justify-end p-6 text-white">
                    <div className="mb-3 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                      <IconComponent size={32} className="text-amber-300 mb-2" />
                    </div>
                    <h3 className="text-xl font-bold mb-1" style={{ fontFamily: 'Playfair Display' }}>
                      {category.name}
                    </h3>
                    <p className="text-sm opacity-90" style={{ fontFamily: 'Lato' }}>
                      {category.description}
                    </p>
                  </div>

                  {/* Decorative Border */}
                  <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-amber-500 to-amber-600 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500"></div>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default FeaturedCategories;