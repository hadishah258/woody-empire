import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, MessageCircle } from 'lucide-react';

const CollectionPage = () => {
  const { category } = useParams<{ category: string }>();
  
  const getCollectionData = (categoryName: string) => {
    const collections: { [key: string]: any } = {
      'living-room': {
        title: 'Living Room Collection',
        description: 'Elegant seating and entertainment furniture crafted for comfort and style',
        items: [
          {
            id: 1,
            name: 'Royal Sofa Set',
            image: 'https://images.pexels.com/photos/1648776/pexels-photo-1648776.jpeg',
            description: 'Luxurious 3-piece sofa set with premium upholstery and brass accents'
          },
          {
            id: 2,
            name: 'Heritage Coffee Table',
            image: 'https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg',
            description: 'Handcrafted wooden coffee table with traditional carved details'
          },
          {
            id: 3,
            name: 'Executive Armchair',
            image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg',
            description: 'Premium leather armchair with solid wood frame'
          },
          {
            id: 4,
            name: 'Entertainment Unit',
            image: 'https://images.pexels.com/photos/667838/pexels-photo-667838.jpeg',
            description: 'Modern TV unit with traditional woodwork elements'
          },
          {
            id: 5,
            name: 'Accent Side Table',
            image: 'https://images.pexels.com/photos/1395967/pexels-photo-1395967.jpeg',
            description: 'Elegant side table with brass inlay work'
          },
          {
            id: 6,
            name: 'Luxury Recliner',
            image: 'https://images.pexels.com/photos/271816/pexels-photo-271816.jpeg',
            description: 'Comfortable reclining chair with premium finish'
          }
        ]
      },
      'bedroom': {
        title: 'Bedroom Collection',
        description: 'Luxurious bedroom furniture combining comfort with traditional craftsmanship',
        items: [
          {
            id: 1,
            name: 'Royal Bed Set',
            image: 'https://images.pexels.com/photos/271816/pexels-photo-271816.jpeg',
            description: 'King-size bed with carved headboard and matching side tables'
          },
          {
            id: 2,
            name: 'Heritage Wardrobe',
            image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg',
            description: 'Spacious wardrobe with traditional mirror work'
          },
          {
            id: 3,
            name: 'Dressing Table',
            image: 'https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg',
            description: 'Elegant dressing table with ornate mirror frame'
          },
          {
            id: 4,
            name: 'Bedside Chest',
            image: 'https://images.pexels.com/photos/1648776/pexels-photo-1648776.jpeg',
            description: 'Compact storage chest with brass handles'
          },
          {
            id: 5,
            name: 'Ottoman Bench',
            image: 'https://images.pexels.com/photos/667838/pexels-photo-667838.jpeg',
            description: 'Upholstered bench with hidden storage'
          },
          {
            id: 6,
            name: 'Study Desk',
            image: 'https://images.pexels.com/photos/1395967/pexels-photo-1395967.jpeg',
            description: 'Compact writing desk with drawers'
          }
        ]
      },
      'dining': {
        title: 'Dining Collection',
        description: 'Exquisite dining furniture for memorable family gatherings',
        items: [
          {
            id: 1,
            name: 'Grand Dining Table',
            image: 'https://images.pexels.com/photos/1395967/pexels-photo-1395967.jpeg',
            description: '8-seater dining table with traditional joinery'
          },
          {
            id: 2,
            name: 'Dining Chairs Set',
            image: 'https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg',
            description: 'Matching chairs with upholstered seats'
          },
          {
            id: 3,
            name: 'China Cabinet',
            image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg',
            description: 'Display cabinet with glass doors and lighting'
          },
          {
            id: 4,
            name: 'Buffet Server',
            image: 'https://images.pexels.com/photos/667838/pexels-photo-667838.jpeg',
            description: 'Elegant serving unit with storage compartments'
          },
          {
            id: 5,
            name: 'Bar Cart',
            image: 'https://images.pexels.com/photos/1648776/pexels-photo-1648776.jpeg',
            description: 'Mobile bar cart with brass accents'
          },
          {
            id: 6,
            name: 'Corner Cabinet',
            image: 'https://images.pexels.com/photos/271816/pexels-photo-271816.jpeg',
            description: 'Space-saving corner display unit'
          }
        ]
      },
      'office': {
        title: 'Office Collection',
        description: 'Professional furniture that combines functionality with elegant design',
        items: [
          {
            id: 1,
            name: 'Executive Desk',
            image: 'https://images.pexels.com/photos/667838/pexels-photo-667838.jpeg',
            description: 'Large executive desk with leather top and storage'
          },
          {
            id: 2,
            name: 'Office Chair',
            image: 'https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg',
            description: 'Ergonomic office chair with premium upholstery'
          },
          {
            id: 3,
            name: 'Bookshelf Unit',
            image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg',
            description: 'Tall bookshelf with adjustable shelves'
          },
          {
            id: 4,
            name: 'Conference Table',
            image: 'https://images.pexels.com/photos/1395967/pexels-photo-1395967.jpeg',
            description: '12-seater conference table with cable management'
          },
          {
            id: 5,
            name: 'Filing Cabinet',
            image: 'https://images.pexels.com/photos/1648776/pexels-photo-1648776.jpeg',
            description: 'Secure filing cabinet with lock system'
          },
          {
            id: 6,
            name: 'Reception Desk',
            image: 'https://images.pexels.com/photos/271816/pexels-photo-271816.jpeg',
            description: 'Modern reception desk with storage'
          }
        ]
      },
      'custom': {
        title: 'Custom Collection',
        description: 'Bespoke furniture pieces designed to your exact specifications',
        items: [
          {
            id: 1,
            name: 'Custom Dining Set',
            image: 'https://images.pexels.com/photos/1395967/pexels-photo-1395967.jpeg',
            description: 'Personalized dining set with unique design elements'
          },
          {
            id: 2,
            name: 'Bespoke Wardrobe',
            image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg',
            description: 'Custom-built wardrobe to fit your space perfectly'
          },
          {
            id: 3,
            name: 'Artisan Cabinet',
            image: 'https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg',
            description: 'Hand-carved cabinet with traditional motifs'
          },
          {
            id: 4,
            name: 'Designer Bed Frame',
            image: 'https://images.pexels.com/photos/271816/pexels-photo-271816.jpeg',
            description: 'Custom bed frame with intricate headboard design'
          },
          {
            id: 5,
            name: 'Unique Coffee Table',
            image: 'https://images.pexels.com/photos/667838/pexels-photo-667838.jpeg',
            description: 'One-of-a-kind coffee table with artistic elements'
          },
          {
            id: 6,
            name: 'Custom Bookshelf',
            image: 'https://images.pexels.com/photos/1648776/pexels-photo-1648776.jpeg',
            description: 'Built-in bookshelf system with decorative panels'
          }
        ]
      },
      'signature': {
        title: 'Signature Collection',
        description: 'Our most celebrated pieces representing the pinnacle of Pakistani craftsmanship',
        items: [
          {
            id: 1,
            name: 'Heritage Dining Set',
            image: 'https://images.pexels.com/photos/1395967/pexels-photo-1395967.jpeg',
            description: 'Handcrafted with traditional joinery techniques using solid Sheesham wood'
          },
          {
            id: 2,
            name: 'Royal Living Suite',
            image: 'https://images.pexels.com/photos/1648776/pexels-photo-1648776.jpeg',
            description: 'Luxury seating inspired by Mughal architecture with premium upholstery'
          },
          {
            id: 3,
            name: 'Artisan Bedroom Collection',
            image: 'https://images.pexels.com/photos/271816/pexels-photo-271816.jpeg',
            description: 'Contemporary comfort with traditional aesthetics and storage integration'
          },
          {
            id: 4,
            name: 'Master Craftsman Desk',
            image: 'https://images.pexels.com/photos/667838/pexels-photo-667838.jpeg',
            description: 'Executive desk featuring hand-carved details and brass inlays'
          },
          {
            id: 5,
            name: 'Imperial Cabinet',
            image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg',
            description: 'Showcase cabinet with intricate mirror work and LED lighting'
          },
          {
            id: 6,
            name: 'Throne Chair',
            image: 'https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg',
            description: 'Majestic chair with hand-carved backrest and premium leather'
          }
        ]
      }
    };
    
    return collections[categoryName] || collections['living-room'];
  };

  const handleWhatsAppContact = (itemName: string) => {
    const phoneNumber = '923197423034';
    const message = `Hi! I'm interested in the ${itemName} from Woody Empire. Could you please provide more details?`;
    const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const collectionData = getCollectionData(category || 'living-room');

  return (
    <div className="min-h-screen bg-stone-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Back Button */}
        <Link 
          to="/"
          className="inline-flex items-center text-amber-700 hover:text-amber-800 mb-8 transition-colors duration-300"
        >
          <ArrowLeft size={20} className="mr-2" />
          <span style={{ fontFamily: 'Lato' }}>Back to Home</span>
        </Link>

        {/* Collection Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-stone-800 mb-4" style={{ fontFamily: 'Playfair Display' }}>
            {collectionData.title}
          </h1>
          <div className="w-24 h-1 bg-amber-600 mx-auto mb-6"></div>
          <p className="text-lg text-stone-600 max-w-2xl mx-auto" style={{ fontFamily: 'Lato' }}>
            {collectionData.description}
          </p>
        </div>

        {/* Items Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {collectionData.items.map((item: any) => (
            <div
              key={item.id}
              className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2"
            >
              <div className="relative overflow-hidden">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-64 object-cover hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 hover:opacity-100 transition-opacity duration-300"></div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold text-stone-800 mb-3" style={{ fontFamily: 'Playfair Display' }}>
                  {item.name}
                </h3>
                <p className="text-stone-600 mb-6 leading-relaxed" style={{ fontFamily: 'Lato' }}>
                  {item.description}
                </p>
                
                {/* WhatsApp Contact Button */}
                <button
                  onClick={() => handleWhatsAppContact(item.name)}
                  className="w-full bg-green-600 hover:bg-green-700 text-white py-3 px-6 font-medium transition-all duration-300 transform hover:scale-105 shadow-md hover:shadow-lg flex items-center justify-center"
                  style={{ fontFamily: 'Lato' }}
                >
                  <MessageCircle size={20} className="mr-2" />
                  Contact via WhatsApp
                </button>
              </div>

              {/* Decorative Border */}
              <div className="h-1 bg-gradient-to-r from-amber-500 via-amber-600 to-amber-700"></div>
            </div>
          ))}
        </div>

        {/* Contact Section */}
        <div className="mt-16 text-center bg-white rounded-xl shadow-lg p-8">
          <h3 className="text-2xl font-bold text-stone-800 mb-4" style={{ fontFamily: 'Playfair Display' }}>
            Need Something Custom?
          </h3>
          <p className="text-stone-600 mb-6" style={{ fontFamily: 'Lato' }}>
            Can't find exactly what you're looking for? We specialize in custom furniture designed to your exact specifications.
          </p>
          <button
            onClick={() => handleWhatsAppContact('Custom Furniture Inquiry')}
            className="bg-amber-600 hover:bg-amber-700 text-white py-3 px-8 font-medium transition-all duration-300 transform hover:scale-105 shadow-md hover:shadow-lg"
            style={{ fontFamily: 'Lato' }}
          >
            Discuss Custom Design
          </button>
        </div>
      </div>
    </div>
  );
};

export default CollectionPage;