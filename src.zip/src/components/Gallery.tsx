import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, X } from 'lucide-react';

const Gallery = () => {
  const [selectedImage, setSelectedImage] = useState<number | null>(null);

  const images = [
    {
      src: 'https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg',
      title: 'Handcrafted Wooden Chair',
      category: 'Living Room'
    },
    {
      src: 'https://images.pexels.com/photos/1648776/pexels-photo-1648776.jpeg',
      title: 'Elegant Sofa Set',
      category: 'Living Room'
    },
    {
      src: 'https://images.pexels.com/photos/271816/pexels-photo-271816.jpeg',
      title: 'Luxury Bedroom Suite',
      category: 'Bedroom'
    },
    {
      src: 'https://images.pexels.com/photos/1395967/pexels-photo-1395967.jpeg',
      title: 'Dining Table Masterpiece',
      category: 'Dining'
    },
    {
      src: 'https://images.pexels.com/photos/667838/pexels-photo-667838.jpeg',
      title: 'Executive Office Desk',
      category: 'Office'
    },
    {
      src: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg',
      title: 'Custom Storage Cabinet',
      category: 'Custom'
    },
    {
      src: 'https://images.pexels.com/photos/1648776/pexels-photo-1648776.jpeg',
      title: 'Modern Coffee Table',
      category: 'Living Room'
    },
    {
      src: 'https://images.pexels.com/photos/271816/pexels-photo-271816.jpeg',
      title: 'Designer Wardrobe',
      category: 'Bedroom'
    }
  ];

  const openLightbox = (index: number) => {
    setSelectedImage(index);
  };

  const closeLightbox = () => {
    setSelectedImage(null);
  };

  const nextImage = () => {
    if (selectedImage !== null) {
      setSelectedImage((selectedImage + 1) % images.length);
    }
  };

  const prevImage = () => {
    if (selectedImage !== null) {
      setSelectedImage(selectedImage === 0 ? images.length - 1 : selectedImage - 1);
    }
  };

  return (
    <section id="gallery" className="py-20 bg-stone-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-stone-800 mb-4" style={{ fontFamily: 'Playfair Display' }}>
            Our Gallery
          </h2>
          <div className="w-24 h-1 bg-amber-600 mx-auto mb-6"></div>
          <p className="text-lg text-stone-600 max-w-2xl mx-auto" style={{ fontFamily: 'Lato' }}>
            Explore our portfolio of exceptional furniture pieces, each showcasing the artistry and craftsmanship that defines Woody Empire
          </p>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {images.map((image, index) => (
            <div
              key={index}
              className="group cursor-pointer overflow-hidden rounded-lg shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:scale-105"
              onClick={() => openLightbox(index)}
            >
              <div className="relative aspect-square overflow-hidden">
                <img
                  src={image.src}
                  alt={image.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors duration-300"></div>
                
                {/* Overlay Content */}
                <div className="absolute inset-0 flex flex-col justify-end p-4 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <h3 className="text-lg font-bold mb-1" style={{ fontFamily: 'Playfair Display' }}>
                    {image.title}
                  </h3>
                  <p className="text-sm text-amber-300" style={{ fontFamily: 'Lato' }}>
                    {image.category}
                  </p>
                </div>

                {/* Category Badge */}
                <div className="absolute top-4 left-4 bg-amber-600 text-white px-3 py-1 text-xs font-medium rounded-full opacity-90">
                  {image.category}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {selectedImage !== null && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4">
          <div className="relative max-w-4xl w-full">
            <img
              src={images[selectedImage].src}
              alt={images[selectedImage].title}
              className="w-full h-auto max-h-[80vh] object-contain rounded-lg"
            />
            
            {/* Close Button */}
            <button
              onClick={closeLightbox}
              className="absolute top-4 right-4 text-white hover:text-amber-300 transition-colors"
            >
              <X size={32} />
            </button>

            {/* Navigation Arrows */}
            <button
              onClick={prevImage}
              className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white hover:text-amber-300 transition-colors"
            >
              <ChevronLeft size={48} />
            </button>
            <button
              onClick={nextImage}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 text-white hover:text-amber-300 transition-colors"
            >
              <ChevronRight size={48} />
            </button>

            {/* Image Info */}
            <div className="absolute bottom-4 left-4 text-white">
              <h3 className="text-xl font-bold" style={{ fontFamily: 'Playfair Display' }}>
                {images[selectedImage].title}
              </h3>
              <p className="text-amber-300" style={{ fontFamily: 'Lato' }}>
                {images[selectedImage].category}
              </p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

export default Gallery;