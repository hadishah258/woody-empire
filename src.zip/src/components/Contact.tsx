import React, { useState } from "react";
import { MapPin, Phone, Mail, Clock } from "lucide-react";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
  });

  const handleInputChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Create mailto link with form data
    const mailtoLink = `mailto:woodyempire.furniture@gmail.com?subject=${encodeURIComponent(
      formData.subject
    )}&body=${encodeURIComponent(
      `Name: ${formData.name}\nEmail: ${formData.email}\nPhone: ${formData.phone}\n\nMessage:\n${formData.message}`
    )}`;

    // Open email app
    window.open(mailtoLink, "_blank");

    // Reset form
    setFormData({
      name: "",
      email: "",
      phone: "",
      subject: "",
      message: "",
    });
  };

  return (
    <section id="contact" className="py-20 bg-stone-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2
            className="text-4xl font-bold text-stone-800 mb-4"
            style={{ fontFamily: "Playfair Display" }}
          >
            Get In Touch
          </h2>
          <div className="w-24 h-1 bg-amber-600 mx-auto mb-6"></div>
          <p
            className="text-lg text-stone-600 max-w-2xl mx-auto"
            style={{ fontFamily: "Lato" }}
          >
            Ready to bring exceptional furniture to your space? Contact us to
            discuss your requirements and discover the Woody Empire difference
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Contact Information */}
          <div className="space-y-8">
            <div>
              <h3
                className="text-2xl font-bold text-stone-800 mb-6"
                style={{ fontFamily: "Playfair Display" }}
              >
                Visit Our Showroom
              </h3>

              <div className="space-y-6">
                <div className="flex items-start">
                  <MapPin
                    className="text-amber-600 mr-4 mt-1 flex-shrink-0"
                    size={20}
                  />
                  <div>
                    <h4
                      className="font-semibold text-stone-800 mb-1"
                      style={{ fontFamily: "Lato" }}
                    >
                      Address
                    </h4>
                    <p
                      className="text-stone-600"
                      style={{ fontFamily: "Lato" }}
                    >
                      Main Murree Road
                      <br />
                      Waris Khan Stop
                      <br />
                      Rawalpindi, Pakistan
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <Phone
                    className="text-amber-600 mr-4 mt-1 flex-shrink-0"
                    size={20}
                  />
                  <div>
                    <h4
                      className="font-semibold text-stone-800 mb-1"
                      style={{ fontFamily: "Lato" }}
                    >
                      Phone
                    </h4>
                    <p
                      className="text-stone-600"
                      style={{ fontFamily: "Lato" }}
                    >
                      +92 3049997996
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <Mail
                    className="text-amber-600 mr-4 mt-1 flex-shrink-0"
                    size={20}
                  />
                  <div>
                    <h4
                      className="font-semibold text-stone-800 mb-1"
                      style={{ fontFamily: "Lato" }}
                    >
                      Email
                    </h4>
                    <p
                      className="text-stone-600"
                      style={{ fontFamily: "Lato" }}
                    >
                      woodyempire.furniture@gmail.com
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <Clock
                    className="text-amber-600 mr-4 mt-1 flex-shrink-0"
                    size={20}
                  />
                  <div>
                    <h4
                      className="font-semibold text-stone-800 mb-1"
                      style={{ fontFamily: "Lato" }}
                    >
                      Hours
                    </h4>
                    <p
                      className="text-stone-600"
                      style={{ fontFamily: "Lato" }}
                    >
                      Monday - Saturday: 10am - 8pm
                      <br />
                      Sunday: 2pm - 7pm
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-lg p-8">
              <h3
                className="text-2xl font-bold text-stone-800 mb-6"
                style={{ fontFamily: "Playfair Display" }}
              >
                Send us a Message
              </h3>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label
                      htmlFor="name"
                      className="block text-sm font-medium text-stone-700 mb-2"
                      style={{ fontFamily: "Lato" }}
                    >
                      Full Name *
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      required
                      value={formData.name}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-colors"
                      placeholder="Enter your full name"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="email"
                      className="block text-sm font-medium text-stone-700 mb-2"
                      style={{ fontFamily: "Lato" }}
                    >
                      Email Address *
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      required
                      value={formData.email}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-colors"
                      placeholder="Enter your email"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label
                      htmlFor="phone"
                      className="block text-sm font-medium text-stone-700 mb-2"
                      style={{ fontFamily: "Lato" }}
                    >
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-colors"
                      placeholder="+92 300 1234567"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="subject"
                      className="block text-sm font-medium text-stone-700 mb-2"
                      style={{ fontFamily: "Lato" }}
                    >
                      Subject *
                    </label>
                    <select
                      id="subject"
                      name="subject"
                      required
                      value={formData.subject}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-colors"
                    >
                      <option value="">Select a subject</option>
                      <option value="general-inquiry">General Inquiry</option>
                      <option value="custom-order">Custom Order</option>
                      <option value="showroom-visit">Showroom Visit</option>
                      <option value="catalog-request">Catalog Request</option>
                      <option value="bulk-order">Bulk Order</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="message"
                    className="block text-sm font-medium text-stone-700 mb-2"
                    style={{ fontFamily: "Lato" }}
                  >
                    Message *
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    required
                    rows={5}
                    value={formData.message}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-colors resize-none"
                    placeholder="Tell us about your furniture requirements..."
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-700 hover:to-amber-800 text-white py-4 px-8 font-medium transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl"
                  style={{ fontFamily: "Lato" }}
                >
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>

        {/* Map Section */}
        <div className="mt-16">
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3321.8234567890123!2d73.0479!3d33.6844!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzPCsDQxJzA0LjAiTiA3M8KwMDInNTIuNCJF!5e0!3m2!1sen!2s!4v1234567890123!5m2!1sen!2s"
              width="100%"
              height="400"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Woody Empire Location - Main Murree Road, Waris Khan Stop, Rawalpindi"
            ></iframe>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
